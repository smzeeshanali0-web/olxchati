package com.olxchat

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private lateinit var etUrls: EditText
    private lateinit var etStart: EditText
    private lateinit var etEnd: EditText
    private lateinit var etMsg: EditText
    private lateinit var tvLog: TextView
    private var running = false
    private var pending: CompletableDeferred<String>? = null
    private var loaded: CompletableDeferred<Unit>? = null
    private val prefs by lazy { getSharedPreferences("olx", MODE_PRIVATE) }

    inner class Bridge {
        @JavascriptInterface
        fun result(s: String) { pending?.complete(s) }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 16, 16, 16) }

        etUrls = EditText(this).apply { hint = "Category URLs (har line mein 1)"; minLines = 3; textSize = 12f }
        etStart = EditText(this).apply { hint = "Start page"; setText("1"); inputType = 2 }
        etEnd = EditText(this).apply { hint = "End page"; setText("2"); inputType = 2 }
        etMsg = EditText(this).apply { setText("Salam, kya yeh available hai? Mujhse rabta karein."); minLines = 2; textSize = 12f }
        val pages = LinearLayout(this)
        pages.addView(etStart, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        pages.addView(etEnd, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))

        val btnLogin = Button(this).apply { text = "1) Login (OLX)" }
        val btnStart = Button(this).apply { text = "2) Start" }
        val btnStop = Button(this).apply { text = "Stop"; setTextColor(Color.RED) }
        val btns = LinearLayout(this)
        listOf(btnLogin, btnStart, btnStop).forEach { btns.addView(it, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)) }

        tvLog = TextView(this).apply { textSize = 11f }
        panel.addView(etUrls); panel.addView(pages); panel.addView(etMsg); panel.addView(btns); panel.addView(tvLog)
        val scroll = ScrollView(this).apply { addView(panel) }

        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView?, url: String?) { loaded?.complete(Unit) }
        }
        web.loadUrl("https://www.olx.com.pk")

        root.addView(scroll, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        root.addView(web, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1.4f))
        setContentView(root)

        btnLogin.setOnClickListener { web.loadUrl("https://www.olx.com.pk") ; log("WebView mein OLX par login karein, phir Start dabayein.") }
        btnStop.setOnClickListener { running = false; log("Stopping...") }
        btnStart.setOnClickListener { if (!running) start() }
    }

    private fun log(s: String) { runOnUiThread { tvLog.text = s + "\n" + tvLog.text.toString().take(3000) } }

    private suspend fun navigate(url: String) {
        loaded = CompletableDeferred()
        web.loadUrl(url)
        withTimeoutOrNull(25000) { loaded!!.await() }
        delay(3500)
    }

    private suspend fun runJs(script: String, timeout: Long): String {
        pending = CompletableDeferred()
        web.evaluateJavascript(script, null)
        return withTimeoutOrNull(timeout) { pending!!.await() } ?: ""
    }

    private fun start() {
        val cats = etUrls.text.toString().lines().map { it.trim() }.filter { it.contains("olx.com.pk") }
        val sp = etStart.text.toString().toIntOrNull() ?: 1
        val ep = etEnd.text.toString().toIntOrNull() ?: 1
        val msg = etMsg.text.toString().trim()
        if (cats.isEmpty() || msg.isEmpty() || sp > ep) { log("Valid URLs, message aur page range daalein."); return }
        running = true
        lifecycleScope.launch {
            val sent = prefs.getStringSet("sent", emptySet())!!.toMutableSet()
            for (cat in cats) {
                val base = cat.substringBefore("?")
                for (page in sp..ep) {
                    if (!running) break
                    log("Page $page: $base")
                    navigate("$base?page=$page")
                    var urls = parseUrls(runJs(LINKS_JS, 20000))
                    if (urls.isEmpty()) { delay(4000); urls = parseUrls(runJs(LINKS_JS, 20000)) }
                    val fresh = urls.filter { it !in sent }
                    var n = 0
                    for (u in fresh) {
                        if (!running) break
                        n++
                        navigate(u)
                        val raw = runJs(CHAT_JS.replace("__MSG__", JSONObject.quote(msg)), 60000)
                        val status = try { JSONObject(raw).getString("status") } catch (e: Exception) { "No response" }
                        val title = try { JSONObject(raw).getString("title").take(30) } catch (e: Exception) { u }
                        log("[$n/${fresh.size}] $title -> $status")
                        if (status.contains("Sent")) {
                            sent.add(u)
                            prefs.edit().putStringSet("sent", sent).apply()
                        }
                        delay(3000 + (Math.random() * 3000).toLong())
                    }
                }
            }
            running = false
            log("Finished / stopped.")
        }
    }

    private fun parseUrls(raw: String): List<String> {
        return try {
            val a = JSONArray(raw)
            val out = ArrayList<String>()
            for (i in 0 until a.length()) out.add(a.getString(i))
            out
        } catch (ex: Exception) {
            emptyList()
        }
    }

    companion object {
        const val LINKS_JS = """
(async function(){
  const wait=ms=>new Promise(r=>setTimeout(r,ms));
  for(let i=0;i<4;i++){window.scrollBy(0,1500);await wait(700);}
  const urls=[];
  document.querySelectorAll('a[href*="/item/"]').forEach(a=>{
    const h=a.getAttribute('href'); if(!h) return;
    let f=h.startsWith('http')?h:'https://www.olx.com.pk'+h;
    f=f.split('?')[0]; if(!urls.includes(f)) urls.push(f);
  });
  Android.result(JSON.stringify(urls));
})();
"""
        const val CHAT_JS = """
(async function(){
  const wait=ms=>new Promise(r=>setTimeout(r,ms));
  let title='Unknown Title', price='N/A', status='Chat Failed';
  function done(){Android.result(JSON.stringify({title:title,price:String(price),status:status}));}
  try{
    const s=document.querySelector('script[type="application/ld+json"]');
    if(s){const j=JSON.parse(s.innerText); if(j.name) title=j.name;
      if(j.offers) price=Array.isArray(j.offers)?(j.offers[0].price||'N/A'):(j.offers.price||'N/A');}
  }catch(e){}
  if(title==='Unknown Title'){const h=document.querySelector('h1'); if(h) title=h.innerText;}
  try{
    const all=Array.from(document.querySelectorAll('button, a, span'));
    const chatBtn=all.find(b=>{
      const t=(b.innerText||'').toLowerCase().trim();
      const a=(b.getAttribute('aria-label')||'').toLowerCase().trim();
      return t.includes('chat')||a.includes('chat');
    });
    if(!chatBtn){status='Chat Hidden';done();return;}
    chatBtn.click(); await wait(4000);
    const input=document.querySelector('textarea')||
      document.querySelector('input[placeholder*="message" i]')||
      document.querySelector('input[placeholder*="Write" i]')||
      document.querySelector('div[contenteditable="true"]')||
      document.querySelector('div[role="textbox"]');
    if(!input){status='Field Blocked / Not Logged In';done();return;}
    input.focus(); input.click(); await wait(500);
    const msg=__MSG__;
    if(input.isContentEditable){input.textContent=msg; input.dispatchEvent(new Event('input',{bubbles:true}));}
    else{
      const proto=input.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
      Object.getOwnPropertyDescriptor(proto,'value').set.call(input,msg);
      input.dispatchEvent(new Event('input',{bubbles:true}));
      input.dispatchEvent(new Event('change',{bubbles:true}));
    }
    await wait(1200);
    const sendBtn=Array.from(document.querySelectorAll('button,[role="button"],[data-aut-id*="send"]')).find(el=>{
      const t=((el.innerText||'')+' '+(el.getAttribute('aria-label')||'')+' '+(el.getAttribute('title')||'')+' '+(el.getAttribute('data-aut-id')||'')).toLowerCase();
      return t.includes('send');
    });
    if(sendBtn){sendBtn.click(); status='Message Sent';}
    else{
      const o={key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true,cancelable:true};
      input.dispatchEvent(new KeyboardEvent('keydown',o));
      input.dispatchEvent(new KeyboardEvent('keypress',o));
      input.dispatchEvent(new KeyboardEvent('keyup',o));
      status='Sent (Enter)';
    }
    await wait(2000);
  }catch(e){status='Error';}
  done();
})();
"""
    }
}
